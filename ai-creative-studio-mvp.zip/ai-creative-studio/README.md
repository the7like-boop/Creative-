# AI Creative Studio – MVP Scaffold

Responsive German-language creative studio with a React/Vite frontend and Express API.

## Included
- Dashboard and navigation for image, video, reference, projects and settings areas
- Image/video job submission UI
- Reference image upload (PNG/JPG/WEBP, max. 20 MB)
- Social presets: Instagram Reels, TikTok, Facebook Reels, Instagram Feed, square and landscape
- Server-side validation of video duration (1–15 seconds)
- Provider adapter contracts for image and video generation
- Explicit mock mode: no fake generated media or false success claims

## Requirements
- Node.js 20+
- npm

## Run locally
```bash
cp .env.example .env
npm install
npm run dev
```
Open the Vite URL printed in the terminal (normally http://localhost:5173). API: http://localhost:8787/api/health

## Production build
```bash
npm run build
npm start
```
The Express server serves `dist` after building.

## Connect real AI providers
Implement the provider contracts in `server/providers/imageProvider.js` and `server/providers/videoProvider.js`.
Keep provider API keys in `.env` on the server. Do not expose keys in frontend variables.
Real video providers commonly return asynchronous job IDs; add a provider-specific status polling endpoint and persistent job store before production use.

## Important limitations
This is a runnable MVP scaffold, not a finished generative AI service. Image/video generation is intentionally in mock mode until you configure a provider API and implement its adapter. Social publishing, authentication, billing, cloud storage, durable job queues, and production monitoring are not yet implemented.
